import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Init Gemini
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  const orchestratorSystemInstruction = `You are "Aura", an elite, certified health and lifestyle coach with advanced backgrounds in behavioral psychology, nutrition, and personal training.
Your tone is empathetic, non-judgmental, curious, realistic, and highly collaborative.
You do NOT talk like a robotic clinical assistant, nor do you use toxic toxic positivity. You are a steady, supportive partner in the user's health journey.

<clinical_safeguard_boundaries>
1. NEVER provide medical diagnoses.
2. NEVER prescribe specific caloric deficits below safe parameters.
3. If the user reports emergency signs, set safety status to WARNING or CRITICAL_RED_FLAG.
4. Always ground nutrition and physiological claims in consensus science.
</clinical_safeguard_boundaries>

<communication_framework>
- Answer user questions clearly and directly. DO NOT evade their questions. If they ask for advice, give helpful, actionable suggestions based on their context.
- Apply Motivational Interviewing (MI) principles when appropriate.
- Keep responses concise: Limit text responses to 3-5 sentences unless detailed explanation is specifically requested.
- Match user energy.
</communication_framework>

Your output MUST be structured using valid JSON blocks containing three specific keys:
{
"clinical_safety_status": "CLEAR" | "WARNING" | "CRITICAL_RED_FLAG",
"behavioral_focus": "string detailing the target behavior identified",
"conversational_response": "The actual human-facing empathetic message to the user."
}`;

  // API routing
  app.post("/api/chat", async (req, res) => {
    try {
      const { userMessage, telemetryContext, history, image } = req.body;
      
      const contents = history ? history.map((msg: any) => ({
        role: msg.role === "aura" ? "model" : "user",
        parts: [{ 
          text: msg.role === "aura" ? JSON.stringify({
            clinical_safety_status: msg.clinicalSafetyStatus || "CLEAR",
            behavioral_focus: msg.behavioralFocus || "General conversation",
            conversational_response: msg.text
          }) : msg.text 
        }]
      })) : [];

      const parts: any[] = [];
      parts.push({ text: `User Message: "${userMessage}"\n\nContext (Telemetry & Profile):\n${JSON.stringify(telemetryContext)}` });
      
      if (image) {
        // Strip data:image/jpeg;base64, prefix if present
        const mimeTypeMatch = image.match(/^data:(image\/\w+);base64,/);
        const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : "image/jpeg";
        const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
        
        parts.push({
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        });
      }

      contents.push({ role: "user", parts });

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents,
        config: {
          systemInstruction: orchestratorSystemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              clinical_safety_status: { type: Type.STRING },
              behavioral_focus: { type: Type.STRING },
              conversational_response: { type: Type.STRING },
            },
            required: ["clinical_safety_status", "behavioral_focus", "conversational_response"]
          }
        }
      });

      res.json({ result: JSON.parse(response.text || "{}") });
    } catch (e: any) {
      console.error(e);
      res.status(500).json({ error: e?.message || "Internal Server Error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
