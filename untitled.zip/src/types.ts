export type NavTab = "home" | "coaching" | "habits" | "profile";

export interface Habit {
  id: string;
  title: string;
  subtitle: string;
  completed: boolean;
  alert?: string;
}

export interface TelemetrySummary {
  yesterday_sleep_score: number;
  current_resting_hr: number;
  rolling_rhr_baseline: number;
  current_steps_today: number;
}

export interface UserProfile {
  name: string;
  email?: string;
  goal: string;
  restrictions: string[];
  behavioral_stage: string;
}

export interface UserContext {
  user_profile: UserProfile;
  telemetry_summary: TelemetrySummary;
  external_context: {
    weather: string;
    current_time: string;
  };
  habits: Habit[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "aura";
  text: string;
  image?: string;
  timestamp: Date;
  clinicalSafetyStatus?: string;
  behavioralFocus?: string;
}
