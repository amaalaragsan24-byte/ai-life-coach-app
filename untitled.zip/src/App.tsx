/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, ReactNode } from "react";
import HomeView from "./components/HomeView";
import CoachingView from "./components/CoachingView";
import HabitsView from "./components/HabitsView";
import ProfileView from "./components/ProfileView";
import AuthView from "./components/AuthView";
import { NavTab, UserContext } from "./types";
import { Home, MessageCircle, CheckSquare, User } from "lucide-react";

const INITIAL_CONTEXT: UserContext = {
  user_profile: {
    name: "Alex",
    goal: "Improve metabolic health & weight management",
    restrictions: ["Lactose intolerant", "Chronic knee pain"],
    behavioral_stage: "Contemplation",
  },
  telemetry_summary: {
    yesterday_sleep_score: 58,
    current_resting_hr: 74,
    rolling_rhr_baseline: 65,
    current_steps_today: 1200,
  },
  external_context: {
    weather: "Rainy, 55°F",
    current_time: new Date().toLocaleTimeString([], { hour: '2-digit', minute:'2-digit' }),
  },
  habits: [
    { id: "1", title: "Morning Hydration", subtitle: "(8oz water)", completed: true },
    { id: "2", title: "Deep Breathing", subtitle: "(5 breaths at front door)", completed: false },
    { id: "3", title: "10-Min Restorative Walk", subtitle: "(Outdoor)", completed: false, alert: "Rainy outside. Consider an indoor mobility session instead." },
  ]
};

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<NavTab>("home");
  const [context, setContext] = useState<UserContext>(INITIAL_CONTEXT);
  const [coachingTriggerPayload, setCoachingTriggerPayload] = useState<{ text: string; image?: string } | null>(null);

  const handleLogin = (name: string, email?: string) => {
    setContext(prev => ({
      ...prev,
      user_profile: { ...prev.user_profile, name, email }
    }));
    setIsLoggedIn(true);
  };

  const handleStartWalk = () => {
    setCoachingTriggerPayload({ text: "I'm ready to start my 10-minute restorative walk. Can you guide me?" });
    setActiveTab("coaching");
  };

  const handleScanMeal = (image: string) => {
    setCoachingTriggerPayload({ text: "I just snapped a photo of my meal! Can you give me 3 instant swap suggestions based on this image?", image });
    setActiveTab("coaching");
  };

  if (!isLoggedIn) {
    return <AuthView onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col h-screen w-full max-w-md mx-auto bg-[#0F172A] text-slate-200 font-sans relative overflow-hidden">
      
      {/* Content Area */}
      <main className="flex-1 overflow-y-auto w-full relative">
        {activeTab === "home" && <HomeView context={context} onNavigate={setActiveTab} onStartWalk={handleStartWalk} />}
        {activeTab === "coaching" && <CoachingView context={context} triggerPayload={coachingTriggerPayload} onMsgProcessed={() => setCoachingTriggerPayload(null)} />}
        {activeTab === "habits" && <HabitsView context={context} onUpdate={setContext} onScanMeal={handleScanMeal} />}
        {activeTab === "profile" && <ProfileView context={context} onUpdate={setContext} onLogout={() => setIsLoggedIn(false)} />}
      </main>

      {/* Bottom Navigation */}
      <nav className="h-16 border-t border-slate-700 bg-[#0F172A]/90 backdrop-blur-md flex items-center justify-around px-2 z-50">
        <NavItem tab="home" icon={<Home size={20} />} label="Home" activeTab={activeTab} onClick={setActiveTab} />
        <NavItem tab="coaching" icon={<MessageCircle size={20} />} label="Coaching" activeTab={activeTab} onClick={setActiveTab} />
        <NavItem tab="habits" icon={<CheckSquare size={20} />} label="Habits" activeTab={activeTab} onClick={setActiveTab} />
        <NavItem tab="profile" icon={<User size={20} />} label="Profile" activeTab={activeTab} onClick={setActiveTab} />
      </nav>
    </div>
  );
}

function NavItem({ tab, icon, label, activeTab, onClick }: { tab: NavTab; icon: ReactNode; label: string; activeTab: NavTab; onClick: (t: NavTab) => void }) {
  const isActive = tab === activeTab;
  return (
    <button 
      onClick={() => onClick(tab)}
      className={`flex flex-col items-center justify-center w-16 gap-1 transition-colors ${isActive ? 'text-[#10B981]' : 'text-slate-500 hover:text-slate-300'}`}
    >
      <div className={`${isActive ? 'bg-emerald-500/10 p-1.5 rounded-full' : 'p-1.5'}`}>
         {icon}
      </div>
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

