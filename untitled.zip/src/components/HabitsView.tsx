import { useRef } from "react";
import type { FC, ChangeEvent } from "react";
import { UserContext, Habit } from "../types";
import { CheckCircle2, Circle, Camera, CloudRain } from "lucide-react";
import { motion } from "motion/react";

export default function HabitsView({ context, onUpdate, onScanMeal }: { context: UserContext; onUpdate: (ctx: UserContext) => void; onScanMeal: (image: string) => void }) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleHabit = (id: string) => {
    onUpdate({
      ...context,
      habits: context.habits.map(h => h.id === id ? { ...h, completed: !h.completed } : h)
    });
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        onScanMeal(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-5 flex flex-col gap-6"
    >
      <header className="pt-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-[#10B981] rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
          <CheckCircle2 className="text-white" size={24} />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white mb-0">Today's Micro-Habits</h1>
          <p className="text-xs text-[#10B981] font-medium tracking-widest uppercase">Sunday, June 21</p>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-3 mt-2">
        {context.habits.map(habit => (
          <HabitItem 
            key={habit.id}
            habit={habit}
            onToggle={() => toggleHabit(habit.id)}
          />
        ))}
      </div>

      {/* Dynamic Meal Reconstruction Card */}
      <div className="bg-[#1E293B] mt-4 rounded-2xl p-5 border border-slate-700 relative overflow-hidden flex flex-col gap-4">
        <div className="flex justify-between items-center text-emerald-400">
          <div className="bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20">
             <Camera size={20} />
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-white mb-2 text-lg">Dynamic Meal Reconstruction</h3>
          <p className="text-sm text-slate-300 leading-relaxed mb-4">
            Snap a photo of your meal or ingredients to get 3 instant swap suggestions.
          </p>
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-emerald-500/10 border border-emerald-500/50 hover:bg-emerald-500/20 text-[#10B981] font-semibold px-4 py-2.5 rounded-xl text-sm transition-colors flex items-center justify-center gap-2"
          >
            <Camera size={16} /> Scan Meal
          </button>
        </div>
      </div>
      
    </motion.div>
  );
}

const HabitItem: FC<{ habit: Habit; onToggle: () => void }> = ({ habit, onToggle }) => {
  return (
    <div className={`p-4 rounded-2xl border transition-colors cursor-pointer ${habit.completed ? 'bg-[#1E293B]/50 border-slate-700/50' : 'bg-[#1E293B] border-slate-700'}`} onClick={onToggle}>
      <div className="flex items-center gap-4">
        <button className="text-slate-500 hover:text-[#10B981] transition-colors">
          {habit.completed ? <CheckCircle2 className="text-[#10B981]" size={22} /> : <Circle size={22} />}
        </button>
        <div className="flex-1">
          <h4 className={`text-sm font-medium ${habit.completed ? 'text-slate-400 line-through' : 'text-slate-200'}`}>{habit.title} <span className="text-slate-500 mx-1 font-normal text-xs">{habit.subtitle}</span></h4>
        </div>
      </div>
      {habit.alert && !habit.completed && (
        <div className="mt-3 ml-9 pl-3 border-l-2 border-rose-500/30 text-rose-300/80 text-xs flex items-center gap-2">
          <CloudRain size={12} />
          {habit.alert}
        </div>
      )}
    </div>
  );
};
