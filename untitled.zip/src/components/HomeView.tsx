import { UserContext, NavTab } from "../types";
import { Activity, Footprints, Moon, HeartPulse } from "lucide-react";
import { motion } from "motion/react";

interface Props {
  context: UserContext;
  onNavigate: (tab: NavTab) => void;
  onStartWalk: () => void;
}

export default function HomeView({ context, onNavigate, onStartWalk }: Props) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-5 flex flex-col gap-6"
    >
      <header className="pt-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-[#10B981] rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
          <Activity className="text-white" size={24} />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white mb-0">Hello, {context.user_profile.name}</h1>
          <p className="text-xs text-[#10B981] font-medium tracking-widest uppercase">Today's strain: Low</p>
        </div>
      </header>

      {/* Insight Card */}
      <div className="bg-emerald-900/20 border border-emerald-500/30 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-2 h-2 rounded-full bg-[#10B981]"></div>
          <p className="text-xs font-bold text-[#10B981] uppercase tracking-widest">Aura Insights</p>
        </div>
        <p className="text-sm text-slate-200">
          Your body is recovering from poor sleep. We've scaled back your workout goal today. Let's aim for a 10-minute restorative walk instead of a run.
        </p>
        <button 
          onClick={onStartWalk}
          className="mt-4 bg-[#10B981] hover:bg-emerald-600 text-white font-semibold px-4 py-2 rounded-lg text-sm transition-colors flex items-center gap-2"
        >
          Start Walk <Footprints size={16} />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-4">
        {/* Sleep Card */}
        <div className="bg-[#1E293B] rounded-2xl p-4 border border-slate-700 flex flex-col justify-between aspect-square">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Sleep</span>
            <Moon size={16} className="text-rose-400" />
          </div>
          <div>
            <div className="flex items-end gap-1">
              <span className="text-4xl font-light text-white leading-none">{context.telemetry_summary.yesterday_sleep_score}</span>
            </div>
            <p className="text-[10px] text-rose-300 font-medium mt-1">Poor REM, +20m wake time</p>
          </div>
        </div>

        {/* Steps Card */}
        <div className="bg-[#1E293B] rounded-2xl p-4 border border-slate-700 flex flex-col justify-between aspect-square">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Daily Steps</span>
            <Footprints size={16} className="text-[#10B981]" />
          </div>
          <div>
            <div className="text-3xl font-semibold text-white mb-1">
              {context.telemetry_summary.current_steps_today.toLocaleString()}
            </div>
            <p className="text-[10px] text-slate-500 mt-1">Goal: 8,500</p>
            <div className="w-full bg-slate-700 h-1 rounded-full overflow-hidden mt-3">
               <div className="bg-[#10B981] h-full w-[14%]"></div>
            </div>
          </div>
        </div>

        {/* RHR Card */}
         <div className="bg-[#1E293B] rounded-2xl p-4 border border-slate-700 flex flex-col justify-between aspect-[4/3]">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Resting HR</span>
            <HeartPulse size={16} className="text-rose-400" />
          </div>
          <div>
            <div className="text-2xl font-semibold text-white mt-1">
              {context.telemetry_summary.current_resting_hr}
              <span className="text-xs text-slate-500 ml-1">bpm</span>
            </div>
            <div className="mt-3 h-1 bg-slate-700 rounded-full">
              <div className="bg-[#10B981] h-full w-2/3 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* HRV Card */}
        <div className="bg-[#1E293B] rounded-2xl p-4 border border-slate-700 flex flex-col justify-between aspect-[4/3]">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">HRV</span>
            <Activity size={16} className="text-slate-500" />
          </div>
          <div>
            <div className="text-2xl font-semibold text-white mt-1">
              41
              <span className="text-xs text-slate-500 ml-1">ms</span>
            </div>
            <div className="mt-3 h-1 bg-slate-700 rounded-full">
              <div className="bg-rose-300 h-full w-1/4 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
      
    </motion.div>
  );
}
