import { useState } from "react";
import type { FormEvent } from "react";
import { UserContext } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { User, Target, ShieldAlert, LogOut, Mail, Plus, X, Check } from "lucide-react";

export default function ProfileView({ context, onUpdate, onLogout }: { context: UserContext; onUpdate: (ctx: UserContext) => void; onLogout: () => void }) {
  const [name, setName] = useState(context.user_profile.name);
  const [email, setEmail] = useState(context.user_profile.email || "");
  const [goal, setGoal] = useState(context.user_profile.goal);
  const [restrictions, setRestrictions] = useState<string[]>(context.user_profile.restrictions);
  const [newRestriction, setNewRestriction] = useState("");
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    onUpdate({
      ...context,
      user_profile: {
        ...context.user_profile,
        name,
        email,
        goal,
        restrictions
      }
    });
    
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleAddRestriction = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = newRestriction.trim();
    if (trimmed && !restrictions.includes(trimmed)) {
      setRestrictions([...restrictions, trimmed]);
      setNewRestriction("");
    } else if (restrictions.includes(trimmed)) {
      setNewRestriction(""); // Just clear it if it's a duplicate
    }
  };

  const handleRemoveRestriction = (indexToRemove: number) => {
    setRestrictions(restrictions.filter((_, i) => i !== indexToRemove));
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-5 flex flex-col gap-6 h-full">
      <header className="pt-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-[#1E293B] border border-slate-700 rounded-xl flex items-center justify-center shrink-0">
          <User className="text-white" size={24} />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white mb-0">Profile</h1>
          <p className="text-xs text-[#10B981] font-medium tracking-widest uppercase">Manage your data</p>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto flex flex-col gap-6 pb-6">
        <div className="bg-[#1E293B] p-5 rounded-2xl border border-slate-700 flex flex-col gap-4">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 block">Display Name</label>
            <input 
              type="text" 
              value={name} 
              onChange={e => setName(e.target.value)} 
              className="w-full bg-[#0F172A] border border-slate-700 rounded-xl px-4 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-[#10B981] transition-colors" 
              placeholder="Your name"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1"><Mail size={12}/> Email Address</label>
            <input 
              type="email" 
              value={email} 
              onChange={e => setEmail(e.target.value)} 
              className="w-full bg-[#0F172A] border border-slate-700 rounded-xl px-4 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-[#10B981] transition-colors" 
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1"><Target size={12}/> Primary Goal</label>
            <input 
              type="text" 
              value={goal} 
              onChange={e => setGoal(e.target.value)} 
              className="w-full bg-[#0F172A] border border-slate-700 rounded-xl px-4 py-2.5 text-slate-200 text-sm focus:outline-none focus:border-[#10B981] transition-colors" 
              placeholder="e.g. Lose 10 lbs, Build endurance"
            />
          </div>
          <button 
            onClick={handleSave} 
            disabled={isSaved}
            className={`mt-2 font-semibold py-2.5 rounded-xl transition-all text-sm flex items-center justify-center gap-2 ${isSaved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'bg-[#10B981] hover:bg-emerald-600 text-white'}`}
          >
            {isSaved ? <><Check size={16} /> Saved Successfully</> : "Save Changes"}
          </button>
        </div>

        <div className="bg-[#1E293B] p-5 rounded-2xl border border-slate-700">
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2"><ShieldAlert size={16} className="text-rose-400"/> Health Restrictions</h3>
          
          <form onSubmit={handleAddRestriction} className="flex gap-2 mb-4">
            <input 
              type="text" 
              value={newRestriction}
              onChange={e => setNewRestriction(e.target.value)}
              placeholder="e.g. Knee pain, Peanut allergy"
              className="flex-1 bg-[#0F172A] border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-[#10B981] transition-colors"
            />
            <button type="submit" disabled={!newRestriction.trim()} className="bg-[#10B981] text-white p-2 flex items-center justify-center rounded-xl disabled:opacity-50 transition-opacity">
              <Plus size={18} />
            </button>
          </form>

          <AnimatePresence>
            <ul className="flex flex-col gap-2">
              {restrictions.length === 0 && (
                <li className="text-xs text-slate-500 italic text-center py-2">No health restrictions added.</li>
              )}
              {restrictions.map((r, i) => (
                <motion.li 
                  key={r} 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-[#0F172A] px-3 py-2.5 rounded-lg text-sm text-slate-300 border border-slate-700 flex justify-between items-center overflow-hidden"
                >
                  <span>{r}</span>
                  <button type="button" onClick={() => handleRemoveRestriction(i)} className="text-slate-500 hover:text-rose-400 transition-colors p-1 shrink-0">
                    <X size={14} />
                  </button>
                </motion.li>
              ))}
            </ul>
          </AnimatePresence>
        </div>

        <button onClick={onLogout} className="mt-1 mb-6 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-semibold py-3 rounded-xl transition-colors text-sm flex items-center justify-center gap-2">
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </motion.div>
  );
}
