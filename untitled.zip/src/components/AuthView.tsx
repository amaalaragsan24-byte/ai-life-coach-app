import { useState } from "react";
import type { FormEvent } from "react";
import { Activity } from "lucide-react";
import { motion } from "motion/react";

export default function AuthView({ onLogin }: { onLogin: (name: string, email?: string) => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [showGooglePrompt, setShowGooglePrompt] = useState(false);
  const [googleEmail, setGoogleEmail] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onLogin(name || (email ? email.split('@')[0] : "Alex"), email);
  };

  const handleGoogleLogin = () => {
    if (googleEmail) {
      onLogin(googleEmail.split('@')[0] || "Google User", googleEmail);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0F172A] p-6 text-slate-200 overflow-y-auto">
      <div className="flex-1 flex flex-col justify-center items-center max-w-sm mx-auto w-full min-h-[500px]">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-16 h-16 bg-[#10B981] rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-8 mt-10">
          <Activity className="text-white" size={36} />
        </motion.div>
        
        <h1 className="text-2xl font-bold text-white mb-2 tracking-tight">Welcome to Aura</h1>
        <p className="text-sm text-slate-400 mb-8 text-center">Your elite AI health and lifestyle coach.</p>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
          {!isLogin && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 block">Your Name</label>
              <input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-[#1E293B] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#10B981] transition-colors" placeholder="Alex" />
            </div>
          )}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 block">Email</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full bg-[#1E293B] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#10B981] transition-colors" placeholder="you@example.com" />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 block">Password</label>
            <input type="password" required className="w-full bg-[#1E293B] border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#10B981] transition-colors" placeholder="••••••••" />
          </div>

          <button type="submit" className="w-full bg-[#10B981] hover:bg-emerald-600 text-white font-semibold py-3 rounded-xl transition-colors mt-2">
            {isLogin ? "Sign In" : "Create Account"}
          </button>
        </form>

        <div className="w-full my-6 flex items-center gap-4">
          <div className="h-px bg-slate-800 flex-1"></div>
          <span className="text-[10px] text-slate-500 uppercase tracking-widest">or</span>
          <div className="h-px bg-slate-800 flex-1"></div>
        </div>

        {showGooglePrompt ? (
          <div className="w-full bg-[#1E293B] border border-slate-700 p-4 rounded-xl flex flex-col gap-3">
            <p className="text-xs text-slate-400">Choose a Google Account</p>
            <input type="email" value={googleEmail} onChange={e => setGoogleEmail(e.target.value)} autoFocus className="w-full bg-[#0F172A] border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#10B981] text-sm" placeholder="your.gmail@gmail.com" />
            <div className="flex gap-2">
              <button onClick={() => setShowGooglePrompt(false)} className="flex-1 bg-slate-800 text-slate-300 py-2 rounded-lg text-sm">Cancel</button>
              <button onClick={handleGoogleLogin} disabled={!googleEmail} className="flex-1 bg-white text-slate-900 py-2 rounded-lg text-sm font-semibold disabled:opacity-50">Continue</button>
            </div>
          </div>
        ) : (
          <button type="button" onClick={() => setShowGooglePrompt(true)} className="w-full bg-[#1E293B] border border-slate-700 text-white font-semibold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 hover:bg-slate-800">
             <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
             </svg>
             Continue with Google
          </button>
        )}

        <button onClick={() => setIsLogin(!isLogin)} className="mt-8 text-sm text-[#10B981] hover:underline pb-8">
          {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}
