import React, { useState, useRef, useEffect } from "react";
import { UserContext, ChatMessage } from "../types";
import { Send, Activity, Mic, Cloud } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function CoachingView({ context, triggerPayload, onMsgProcessed }: { context: UserContext; triggerPayload: { text: string; image?: string } | null; onMsgProcessed: () => void; }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Set real initial conversation 
  useEffect(() => {
    setMessages([
      {
        id: "sys-1",
        role: "user",
        text: "Rough day, I'm exhausted and honestly just want to order a whole pizza.",
        timestamp: new Date(Date.now() - 1000 * 60)
      },
      {
        id: "sys-2",
        role: "aura",
        text: `I hear you, ${context.user_profile.name}. After a stressful day and a tough night of sleep (a 58 sleep score), craving that absolute comfort is completely natural. Your body is hunting for quick energy.\n\nBefore you order, how would you feel about a micro-compromise? Order the pizza, but let's commit to having a tall glass of cool water and a handful of spinach first. What feels most supportive to you right now?`,
        timestamp: new Date()
      }
    ]);
  }, [context.user_profile.name]);

  useEffect(() => {
    if (triggerPayload) {
      handleSend(triggerPayload.text, triggerPayload.image);
      onMsgProcessed();
    }
  }, [triggerPayload]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (text: string, image?: string) => {
    if (!text.trim() && !image) return;
    
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      text: text.trim(),
      image,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userMessage: text,
          image: image,
          telemetryContext: context,
          history: [...messages] // Send conversation history (excluding current message which is added in server.js)
        })
      });
      const data = await res.json();
      
      if (data.error) {
        console.error("API Error", data.error);
        throw new Error(data.error);
      }

      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: "aura",
        text: data.result.conversational_response,
        timestamp: new Date(),
        clinicalSafetyStatus: data.result.clinical_safety_status,
        behavioralFocus: data.result.behavioral_focus
      }]);

    } catch (e) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: "aura",
        text: "I'm having trouble connecting to my backend. Can we try again in a moment?",
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0F172A] absolute inset-0">
      <header className="h-16 px-6 border-b border-slate-700 flex items-center justify-between bg-[#0F172A]/90 backdrop-blur-md relative z-10 shrink-0">
        <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
          <div className="w-2 h-2 rounded-full bg-[#10B981]"></div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-200">Watch Linked</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-semibold text-white">{context.user_profile.name}</p>
            <p className="text-[10px] text-slate-400">{context.user_profile.behavioral_stage}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-700 border-2 border-slate-600 overflow-hidden">
            <div className="w-full h-full bg-gradient-to-tr from-emerald-500 to-teal-700"></div>
          </div>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <MessageBubble key={msg.id} msg={msg} />
          ))}
          {isLoading && (
            <motion.div 
              initial={{opacity: 0, scale: 0.95}} 
              animate={{opacity: 1, scale: 1}} 
              className="self-start max-w-[85%] bg-slate-800 text-slate-200 p-4 rounded-2xl rounded-tl-sm border border-slate-700 shadow-sm"
            >
              <div className="flex gap-1.5 justify-center items-center h-4">
                <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="p-6 bg-[#0F172A]/50 border-t border-slate-700 shrink-0">
        <div className="flex gap-4 items-center">
           <div className="w-10 h-10 rounded-full border border-slate-600 flex items-center justify-center text-slate-500 shrink-0">
              <Mic size={20} />
           </div>
           <div className="relative flex-grow bg-slate-800 rounded-2xl border border-slate-700 flex justify-between items-center">
             <input 
               type="text" 
               value={inputValue}
               onChange={(e) => setInputValue(e.target.value)}
               onKeyDown={(e) => {
                 if (e.key === 'Enter') handleSend(inputValue);
               }}
               className="w-full bg-transparent text-slate-200 placeholder:text-slate-500 rounded-2xl pl-4 pr-12 py-3 text-sm focus:outline-none"
               placeholder="Share your thoughts..."
             />
             <button 
               onClick={() => handleSend(inputValue)}
               disabled={!inputValue.trim() || isLoading}
               className="absolute right-2 top-1.5 bottom-1.5 aspect-square disabled:opacity-50 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
             >
               <Send size={18} />
             </button>
           </div>
        </div>
      </div>
    </div>
  );
}

const MessageBubble: React.FC<{ msg: ChatMessage }> = ({ msg }) => {
  const isAura = msg.role === "aura";
  
  return (
    <motion.div 
      initial={{opacity: 0, y: 10}} 
      animate={{opacity: 1, y: 0}}
      className={`flex flex-col max-w-[85%] ${isAura ? "self-start" : "self-end"}`}
    >
      {isAura ? (
        <div className="flex gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#10B981] flex-shrink-0 flex items-center justify-center mt-1">
            <Activity className="w-4 h-4 text-white" />
          </div>
          <div className="bg-emerald-500/10 border border-emerald-500/20 p-5 rounded-2xl rounded-tl-none">
            <p className="text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">{msg.text}</p>
            {msg.text.includes('58 sleep score') && (
              <div className="mt-4 flex gap-2 flex-wrap text-xs">
                <button className="bg-[#10B981]/20 hover:bg-[#10B981]/30 text-emerald-400 px-3 py-1.5 rounded-full border border-[#10B981]/30 transition-colors font-medium">Sounds like a plan</button>
                <button className="bg-slate-800/80 hover:bg-slate-800 text-slate-300 px-3 py-1.5 rounded-full border border-slate-700 transition-colors">Alternative idea</button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-slate-700 p-4 rounded-2xl rounded-tr-none border border-slate-600">
          {msg.image && (
            <img src={msg.image} alt="User Context" className="w-full max-w-xs rounded-xl mb-3 object-cover shadow-sm bg-slate-800" />
          )}
          <p className="text-sm text-white whitespace-pre-wrap">{msg.text}</p>
        </div>
      )}
      
      <div className={`text-[10px] text-slate-500 mt-2 ${isAura ? 'ml-11 text-left' : 'text-right'}`}>
        {isAura ? "Aura Coach • Context Sync Active" : msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
        {isAura && msg.clinicalSafetyStatus && (
           <span className="ml-2 text-slate-600 bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">Flag: {msg.clinicalSafetyStatus}</span>
        )}
      </div>
    </motion.div>
  );
}
